const { defineConfig } = require("cypress");

const webpack = require("@cypress/webpack-preprocessor");
const preprocessor = require("@badeball/cypress-cucumber-preprocessor");

async function setupNodeEvents(on, config) {
  await preprocessor.addCucumberPreprocessorPlugin(on, config);

  on(
    "file:preprocessor",
    webpack({
      webpackOptions: {
        resolve: {
          extensions: [".ts", ".js"],
        },
        module: {
          rules: [
            {
              test: /\.feature$/,
              use: [
                {
                  loader: "@badeball/cypress-cucumber-preprocessor/webpack",
                  options: config,
                },
              ],
            },
          ],
        },
      },
    })
  );
  
  on('before:browser:launch', (browser = {}, launchOptions) => {
        // `args` is an array of all the arguments that will
        // be passed to browsers when it launches
        console.log(launchOptions.args) // print all current args
      
        if (browser.family === 'chromium' && browser.name !== 'electron') {
          // auto open devtools
          launchOptions.args.push('--disable-extensions')
        }
      
        
      
        // whatever you return here becomes the launchOptions
        return launchOptions
      });


  // Make sure to return the config object as it might have been modified by the plugin.
  return config;
}





module.exports = defineConfig({
	
  
  
  e2e: {
	
    specPattern: "cypress/e2e/feature/*.feature",
    supportFile: false,
    setupNodeEvents
  }
});
