class productlistPage{

	elements= {
	
		title : () => cy.get('[class="a-color-state a-text-bold"]'),
		productContainerList: () => cy.get('div[class="a-section a-spacing-small a-spacing-top-small"]')
	
	
	}
	
	check(productName){

		this.elements.title().should('include.text',productName)
	}

	clickOnFirstProduct(){

		this.elements.productContainerList().eq(1)
		.within( () => {
			cy.get('h2 > a').invoke('removeAttr','target').click()
		})
	}


}
export default new productlistPage();