class homepage{
	
	elements={
		
		searchBar : () => cy.get('#twotabsearchtextbox')
	}
	
	searchProducts(productName){
		
		this.elements.searchBar().type(productName+'{enter}')
	}
	
	
}

module.exports = new homepage();