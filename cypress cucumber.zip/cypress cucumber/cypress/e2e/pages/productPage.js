class productPage{

    elements = {

        addToCartBtn : () => cy.get('#add-to-cart-button'),
        verificationText : () => cy.get('[class="a-size-medium-plus a-color-base sw-atc-text a-text-bold"]')
    }

    clickOnBtn(){
        this.elements.addToCartBtn().click()
    }

    verifyProductIsAdded(){

        this.elements.verificationText().should('include.text','Added to Cart')
    }


}

export default new productPage();