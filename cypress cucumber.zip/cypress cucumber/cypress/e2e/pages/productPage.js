class productPage{

	elements= {
	
		headSection : () => cy.get('[class="a-color-state a-text-bold"]')
	
	
	}
	
	


}

module.export = new productPage();