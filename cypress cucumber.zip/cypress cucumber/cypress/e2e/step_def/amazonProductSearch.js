import homepage from '../../e2e/pages/homepage'
import productListPage from '../../e2e/pages/productlistPage'

const { When, Then , Given} = require("@badeball/cypress-cucumber-preprocessor");

var productName = 'iphone'

Given('User is on homepage', () => {
	
	cy.visit('https://www.amazon.in/')
	
});

When('User search for products', () => {
	
	homepage.searchProducts(productName)
	
});

Then('User should able to see the listing for the products', () => {
	
	productListPage.check(productName)
	cy.log('working')
	
});
