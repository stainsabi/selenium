import homepage from '../../e2e/pages/homepage'
import productPage from '../../e2e/pages/productPage'

const { When, Then , Given} = require("@badeball/cypress-cucumber-preprocessor");

var productName = 'iphone'

Given('User is on homepage', () => {
	
	cy.visit('https://www.amazon.in/')
	
});

When('User search for products', () => {
	
	homepage.searchProducts(productName)
	
});

Then('User should able to see the listing for the products', () => {
	
	//productPage.elements.headSection().should('include.text',productName)
	cy.log('working')
	
});
