import homepage from '../../e2e/pages/homepage'
import productListPage from '../../e2e/pages/productlistPage'
import productPage from '../pages/productPage';

const { When, Then , Given} = require("@badeball/cypress-cucumber-preprocessor");

var productName='iphone'

Given('User is in homepage', () => {
    cy.visit('https://www.amazon.in/')
});

When('User search product', () => {

    homepage.searchProducts(productName)
});

Then('User click on the first product', () => {
    productListPage.clickOnFirstProduct()
});

Then('User click on the add to cart button',() => {
    productPage.clickOnBtn()
});

Then('A message Added to Cart is shown',() => {
    productPage.verifyProductIsAdded()
});